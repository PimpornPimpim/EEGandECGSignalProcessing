close all;clear all;clc;
load('ECG.mat');    % Raw data

fsamp = 200;                    % Sampling frequency
tsample = 1/fsamp;              % Period of samples
sec=60;
time=0:tsample:sec;

figure
plot(time(1:end-1),ECG(1:fsamp*sec))
xlabel('Time(sec)'); ylabel('Amplitude')
title('ECG signal ')

% Filter the scaled signal using a Savitzky-Golay filter
ECG=ECG(1:fsamp*sec);
ECG_data = sgolayfilt(ECG, 3, 21);

t = 1:length(ECG_data);
[~,locs_Rwave] = findpeaks(ECG_data,'MinPeakHeight',0.4,...
                                    'MinPeakDistance',50);

% Remove Edge Wave Data
locs_Rwave(locs_Rwave < 150 | locs_Rwave > (length(ECG_data) - 150)) = [];
locs_Qwave = zeros(length(locs_Rwave),1);
locs_Swave = zeros(length(locs_Rwave),1);
locs_Qpre  = zeros(length(locs_Rwave),1);
locs_Spost = zeros(length(locs_Rwave),1);
QRS = zeros(length(locs_Rwave),1);

% Find Q and S waves in the signal
for ii = 1:length(locs_Rwave)
    window = ECG_data((locs_Rwave(ii)-70):(locs_Rwave(ii)+70));
    [d_peaks, locs_peaks] = findpeaks(-window, 'MinPeakDistance',40);
    [d,i] = sort(d_peaks, 'descend');
    locs_Qwave(ii) = locs_peaks(i(1))+(locs_Rwave(ii)-20);
    locs_Swave(ii) = locs_peaks(i(2))+(locs_Rwave(ii)-20);
    [d_QRS, locs_QRS] = findpeaks(window, 'MinPeakDistance', 10);
    [max_d, max_i] = max(d_QRS);
    locs_Q_flat = locs_QRS(max_i-1);
    locs_S_flat = locs_QRS(max_i+1);
    locs_Qpre(ii)  = locs_Q_flat+(locs_Rwave(ii)-80);
    locs_Spost(ii) = locs_S_flat+(locs_Rwave(ii)-80);
    QRS(ii) = locs_S_flat - locs_Q_flat;
end

% Calculate the heart rate
myqrs = median(QRS);
myheartrate = 60./ (median(diff(locs_Rwave))./fsamp)

locs_all = [locs_Qwave; locs_Rwave; locs_Swave; locs_Qpre; locs_Spost];
ECG_all  = ECG_data(locs_all);

[d,i] = sort(locs_all);
ECG_sort = ECG_all(i);

figure
hold on
plot(t,ECG_data);
plot(locs_Rwave,ECG_data(locs_Rwave),'rv','MarkerFaceColor','r');
grid on
% Adjust the plot to show 8 seconds worth of measurements
ylim([-1 2]);
title(sprintf('QRS = %f ms,  Heart Rate = %f / min', myqrs, myheartrate));
xlabel('Samples'); ylabel('Voltage(mV)')
legend('ECG signal','R-wave');

% Obtain RR time series
R_RRi=QRS;
 temp=0;
 for j=1:length(R_RRi)
    ti = R_RRi(j);
    temp = temp+ti;
    timeserie(j) = temp;
 end
 %  interpolation RR interval 
t=timeserie;
rFsf=200;                                      % sampling frequency for resample
tt = t(1):(1/rFsf):t(length(t));           
intRRi=interp1(t,QRS,tt,'cubic');         % interpolation with cubic function
%%%+++++
figure
plot(tt/fsamp,intRRi/fsamp);
xlabel('Time(sec)');ylabel('RRinterval(sec)');title ' RR interval signal'

% Time Domain Parameter
meanRR=mean(intRRi./fsamp)
sdRR=std(intRRi./fsamp)